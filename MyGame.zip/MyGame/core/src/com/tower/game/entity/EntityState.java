package com.tower.game.entity;

public enum EntityState {
    ENTITY_NONE,
    ENTITY_ATTACK,
    ENTITY_HITED,
    ENTITY_DEAD,
    ENTITY_REALDEAD;
}
